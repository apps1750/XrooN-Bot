const Discord = require('discord.js')
const client = new Discord.Client({ partials: ["MESSAGE", "CHANNEL", "REACTION"] })
const config = require('./config.json')
const ms = require('ms')
const fs = require("fs");
const { join } = require("path");
client.db = require("quick.db");
const DBL = require('dblapi.js');
const Topgg = require(`@top-gg/sdk`);
const api = new Topgg.Api(config.DBL_TOKEN);
client.commands = new Discord.Collection();
//client.cooldown = new Discord.Collection();
const cooldowns = new Discord.Collection();
const escapeRegex = (str) => str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
const { GiveawaysManager } = require('discord-giveaways');
client.giveawaysManager = new GiveawaysManager(client, {
  storage: "./giveaways.json",
  updateCountdownEvery: 3000,
  default: {
    botsCanWin: false,
    embedColor: "BLUE",
    reaction: "788373043771998228",
  }
});
client.queue = new Map();


const dbl = new DBL(config.DBL_TOKEN, { webhookPort: 5000, webhookAuth: "JKFGLDASJIOWEPNJLCVDAS"})
/*https://discord.com/api/webhooks/790250279048183850/VEytJUTzGlKdZUPrwAB799H6IWUqAJ1bNyIX4yOC656cnjCScB9eJQQyMFTlC-6yPDpg*/
dbl.webhook.on('vote', (vote) => {
  console.log(`User with ID ${vote.user} just voted!`);
  const webhook = new Discord.WebhookClient("790250279048183850", "VEytJUTzGlKdZUPrwAB799H6IWUqAJ1bNyIX4yOC656cnjCScB9eJQQyMFTlC-6yPDpg")
  let embed = new Discord.MessageEmbed()
    .setAuthor("XRooN Vote", "https://cdn.discordapp.com/attachments/746462160028172348/790250933053292574/a62a05260fb30160effb7bfec3ef3cb7.png", "https://top.gg/bot/786975444561297510/vote")
    .setDescription(`New Vote!\n Mention: <@${vote.user}>\nID: \`${vote.user}\`Thanks!`)
    .setColor("BLUE")
    .setTimestamp()
    .setFooter(client.user.username, client.user.displayAvatarURL())

  webhook.send(embed)
});


const ticketj = JSON.parse(fs.readFileSync("./ticket.json", "utf8"))
//Commands

const commandFiles = fs.readdirSync(join(__dirname, "commands")).filter((file) => file.endsWith(".js"));
for (const file of commandFiles) {
  const command = require(join(__dirname, "commands", `${file}`));
  client.commands.set(command.name, command);
}

client.on("message", async (message) => {
  const PREFIX = client.db.get(`guild_${message.guild.id}_prefix`) || "x!"
  if (message.author.bot) return;
  if (!message.guild) return;
  xp(message);
  const prefixRegex = new RegExp(`^(<@!?${client.user.id}>|${escapeRegex(PREFIX)})\\s*`);
  if (!prefixRegex.test(message.content)) return;

  const [, matchedPrefix] = message.content.match(prefixRegex);

  const args = message.content.slice(matchedPrefix.length).trim().split(/ +/);
  const commandName = args.shift().toLowerCase();

  const command =
    client.commands.get(commandName) ||
    client.commands.find((cmd) => cmd.aliases && cmd.aliases.includes(commandName));

  if (!command) return;

  if (!cooldowns.has(command.name)) {
    cooldowns.set(command.name, new Discord.Collection());
  }

  const now = Date.now();
  const timestamps = cooldowns.get(command.name);
  const cooldownAmount = (command.cooldown || 1) * 1000;

  if (timestamps.has(message.author.id)) {
    const expirationTime = timestamps.get(message.author.id) + cooldownAmount;

    if (now < expirationTime) {
      const timeLeft = (expirationTime - now) / 1000;
      let embed = new Discord.MessageEmbed()
        .setDescription(`Please wait **${timeLeft.toFixed(1)}** more second(s) before reusing the \`${command.name}\` command.`)
        .setColor("BLUE")
      return message.reply(embed);
    }
  }

  timestamps.set(message.author.id, now);
  setTimeout(() => timestamps.delete(message.author.id), cooldownAmount);

  try {
    command.execute(client, message, args);
  } catch (error) {
    console.error(error);
    message.reply("There was an error executing that command.").catch(console.error);
  }
});

client.on('message', msg => {
  client.emit('checkMessage', msg);

})




client.on('ready', ready => {
  console.log('Ready!')
  client.user.setActivity(`x!help | xroon.xyz`, { type: "WATCHING" })
})

client.on('message', async message => {
  client.user.setActivity(`x!help | xroon.xyz`, { type: "WATCHING" })
  let AN = client.db.get(`anti_link_${message.guild.id}`)
  if (message.member.hasPermission("MANAGE_GUILD")) return;
  if (message.content.startsWith('ticket-')) return;
  if (message.content.includes("https://") || message.content.includes(".com") || message.content.includes(".co") || message.content.includes("discord.gg") || message.content.includes("bit.ly")) {
    if (AN) {
      message.delete();
      let embed = new Discord.MessageEmbed()
        /*.setTitle('Links must not be sent on this server!')*/
        .setDescription(`${config.no} | You are not alowed to send links here`)
        .setColor("BLUE")
      message.channel.send(embed)
    }
    else if (AN == null) {
      return;
    }
    else {
      return;
    }
  }
});

client.on('ready', () => {
  client.on('message', async message => {
    const PREFIX = client.db.get(`guild_${message.guild.id}_prefix`) || "x!"

    if (message.content === `${PREFIX}help` || message.content === `${PREFIX}h`) {
      let embed = new Discord.MessageEmbed()
        .setColor('BLUE')
        .setTitle('XRooN Bot Commands')
        .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
        .setDescription("[Support Server](https://discord.gg/hVQqBev8zu) **|** [Invite Me](https://discord.com/oauth2/authorize?client_id=786975444561297510&scope=bot&permissions=2146958847) **|** [Vote Me](https://top.gg/bot/786975444561297510/vote) **|** [Website](https://xroon.xyz/) **|** [Donate](https://donatebot.io/checkout/760424140913246218?buyer=300991412533460993) ")
        .addField('**Info \\🎓**', `\`${PREFIX}help info\``, true)
        .addField('**Moderation \\⚒️**', `\`${PREFIX}help moderation\``, true)
        .addField('**Leveling \\🏆**', `\`${PREFIX}help leveling\``, true)
        .addField('**Ticket 📨**', `\`${PREFIX}help ticket\``, true)
        .addField('**Giveaways \\🎉**', `\`${PREFIX}help giveaways\``, true)
        .addField('**Music \\🎵**', `\`${PREFIX}help music\``, true)
        .addField('**Custom \\⚙️**', `\`${PREFIX}help custom\``, true)
        .addField('**Fun \\🤪**', `\`${PREFIX}help fun\``, true)
        .addField('**XRooN Team \\💻**', 'Lead: **\`IDO#0001\` | \`Adar#9999\`**\nTeam: **\`Finis#6666\`**')
        .setTimestamp()
        .setFooter(`XRooN Team\nPrefix: ${PREFIX}`, client.user.displayAvatarURL({ dynamic: true }))
      message.channel.send(embed)
    }
    if (message.content == `${PREFIX}help info`) {
      let embed = new Discord.MessageEmbed()
        .setColor('BLUE')
        .setTitle('\\🎓 XRooN Info Commands')
        .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
        .setDescription(`\`${PREFIX}server-info\` | \`${PREFIX}user-info\` | \`${PREFIX}bot-info\``)
        .setTimestamp()
        .setFooter(`XRooN Team\nPrefix: ${PREFIX}`, client.user.displayAvatarURL({ dynamic: true }))
      message.channel.send(embed)
    }
    if (message.content == `${PREFIX}help moderation`) {
      let embed = new Discord.MessageEmbed()
        .setColor('BLUE')
        .setTitle('\\⚒️ XRooN Moderation Commands')
        .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
        .setDescription(`**\`${PREFIX}kick\` | \`${PREFIX}ban\` | \`${PREFIX}unban\` | \`${PREFIX}mute\` | \`${PREFIX}slowmode\` | \`${PREFIX}clear\`| \`${PREFIX}nuke\`**`)
        .setTimestamp()
        .setFooter(`XRooN Team\nPrefix: ${PREFIX}`, client.user.displayAvatarURL({ dynamic: true }))
      message.channel.send(embed)
    }
    if (message.content == `${PREFIX}help leveling`) {
      let embed = new Discord.MessageEmbed()
        .setColor('BLUE')
        .setTitle('\\🏆 XRooN Leveling Commands')
        .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
        .setDescription(`**\`${PREFIX}rank\`**`)
        .setTimestamp()
        .setFooter(`XRooN Team\nPrefix: ${PREFIX}`, client.user.displayAvatarURL({ dynamic: true }))
      message.channel.send(embed)
    }
    if (message.content == `${PREFIX}help giveaways`) {
      let embed = new Discord.MessageEmbed()
        .setColor('BLUE')
        .setTitle('\\🎉 XRooN Giveaways Commands')
        .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
        .setDescription(`**\`${PREFIX}start\` | \`${PREFIX}end\` | \`${PREFIX}reroll\`**`)
        .setTimestamp()
        .setFooter(`XRooN Team\nPrefix: ${PREFIX}`, client.user.displayAvatarURL({ dynamic: true }))
      message.channel.send(embed)
    }
    if (message.content == `${PREFIX}help fun`) {
      let embed = new Discord.MessageEmbed()
        .setColor('BLUE')
        .setTitle('\\🤪 XRooN Fun Commands')
        .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
        .setDescription(`**\`${PREFIX}djs\` | \`${PREFIX}corona\` | \`${PREFIX}dbl\` | \`${PREFIX}poll\` | \`${PREFIX}avatar\` | \`${PREFIX}trigger\` | \`${PREFIX}chat\` | \`${PREFIX}ascii\` | \`${PREFIX}fnshop\` | \`${PREFIX}say\` | \`${PREFIX}embed\` | \`${PREFIX}phub\` | \`${PREFIX}wanted\` | \`${PREFIX}wasted\` | \`${PREFIX}blur\` | \`${PREFIX}gay\` | \`${PREFIX}circle\` | \`${PREFIX}jail\` | \`${PREFIX}hitler\` | \`${PREFIX}facepalm\` | \`${PREFIX}rip\` | \`${PREFIX}slap\` | \`${PREFIX}shit\` | \`${PREFIX}affect\`| \`${PREFIX}tictactoe\`**`)
        .setTimestamp()
        .setFooter(`XRooN Team\nPrefix: ${PREFIX}`, client.user.displayAvatarURL({ dynamic: true }))
      message.channel.send(embed)
    }
    if (message.content == `${PREFIX}help music` || message.content == `${PREFIX}h music`) {
      let embed = new Discord.MessageEmbed()
        .setColor('BLUE')
        .setTitle('\\🎵 XRooN Music Commands')
        .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
        .setDescription(`\`${PREFIX}play [p]\` | \`${PREFIX}stop \` | \`${PREFIX}skip [s]\` | \`${PREFIX}volume\` | \`${PREFIX}playlist\` | \`${PREFIX}pause\` | \`${PREFIX}resume\` | \`${PREFIX}queue [q]\` | \`${PREFIX}search\` | \`${PREFIX}nowplaying [np]\` | \`${PREFIX}skipto [st]\``)
        .setTimestamp()
        .setFooter(`XRooN Team\nPrefix: ${PREFIX}`, client.user.displayAvatarURL({ dynamic: true }))
      message.channel.send(embed)
    }
    if (message.content == `${PREFIX}help custom`) {
      let embed = new Discord.MessageEmbed()
        .setColor('BLUE')
        .setTitle('\\⚙️ XRooN Custom Commands')
        .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
        .setDescription(`**\`${PREFIX}set-welcome\` | \`${PREFIX}set-leave\` | \`${PREFIX}set-prefix\` | \`${PREFIX}set-anti-link\` | \`${PREFIX}set-verify\` | \`${PREFIX}disable-welcome\` | \`${PREFIX}disable-leave\` | \`${PREFIX}disable-anti-link\` | \`${PREFIX}disable-verify\`**`)
        .setTimestamp()
        .setFooter(`XRooN Team\nPrefix: ${PREFIX}`, client.user.displayAvatarURL({ dynamic: true }))
      message.channel.send(embed)
    }
    if (message.content == `${PREFIX}help ticket`) {
      let embed = new Discord.MessageEmbed()
        .setColor('BLUE')
        .setTitle('📨 XRooN Ticket Commands')
        .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
        .setDescription(`**\`${PREFIX}ticket-setup\` | \`${PREFIX}add\` | \`${PREFIX}remove\` | \`${PREFIX}rename\` | \`${PREFIX}close\`**`)
        .setTimestamp()
        .setFooter(`XRooN Team\nPrefix: ${PREFIX}`, client.user.displayAvatarURL({ dynamic: true }))
      message.channel.send(embed)
    }

    /////////////////////////////////////////////////////
    var json = JSON.parse(fs.readFileSync("./ticket.json"));
    if (message.content.startsWith(`${PREFIX}ticket-setup`)) {
      if (!message.member.hasPermission("MANAGE_MESSAGES")) return message.reply("You need `MANAGE_MESSAGES` permissions to setup tickets");
      let ido = client.db.get(`guild_${message.guild.id}_ticket`)
      let channel = message.mentions.channels.first();
      if (!channel) return message.reply(`Usage: \`${PREFIX}ticket-setup #channel\``);

      let sent = await channel.send(new Discord.MessageEmbed()
        .setTitle("Ticket System")
        .setDescription("React with 📨 to open a ticket!")
        .setFooter(`${client.user.username} | Ticket System`, client.user.displayAvatarURL())
        .setColor("BLUE")
      );

      sent.react('📨');

      client.db.set(`guild_${message.guild.id}_ticket`, sent.id);
      console.log(channel.id)
      /*json[message.guild.id] = {
        channel: channel.id,
        message2: sent.id
      }
      fs.writeFile("./ticket.json", JSON.stringify(json), (err) => {
        if (err) console.error(err)
      })*/
      message.channel.send("Ticket System Setup Done!")
    }
    if (message.mentions.users.first().id == client.user.id) {
      return message.reply(`Hey, My name is **\`${client.user.username}\`**.\nMy prefix in this guild: \`${PREFIX}\`\nUse \`${PREFIX}help\` for more info`)
      
    }
  })
})


client.on('guildMemberAdd', member => {
  let channelM = client.db.get(`welcome_${member.guild.id}`)
  let description = client.db.get(`wMessage_${member.guild.id}`)
  if (channelM === null) {
    return;
  }
  let embed = new Discord.MessageEmbed()
    .setAuthor(member.user.tag, member.user.displayAvatarURL({ dynamic: true }))
    .setDescription(description.replace("{user}", member).replace("{guild}", member.guild.name).replace("{user_tag}", member.tag))
    .setColor("GREEN")
    .setTimestamp()
    .setFooter(`${client.user.username} | The ${member.guild.memberCount}th member`)

  /*channelM.send(embed)*/
  client.channels.cache.get(channelM).send(embed)
})
client.on('guildMemberRemove', member => {
  let channelM = client.db.get(`leave_${member.guild.id}`)
  let description = client.db.get(`lMessage_${member.guild.id}`)
  if (channelM === null) {
    return;
  }
  let embed = new Discord.MessageEmbed()
    .setAuthor(member.user.tag, member.user.displayAvatarURL({ dynamic: true }))
    .setDescription(description.replace("{user}", member).replace("{guild}", member.guild.name).replace("{user_tag}", member.tag))
    .setColor("RED")
    .setTimestamp()
    .setFooter(`${client.user.username} | The ${member.guild.memberCount}th member`)

  /*channelM.send(embed)*/
  client.channels.cache.get(channelM).send(embed)
})


function xp(message) {
    let xp = client.db.add(`xp_${message.author.id}_guild_${message.guild.id}`, 1);
    let level = Math.floor(0.3 * Math.sqrt(xp));
    let lvl = client.db.get(`level_${message.author.id}_guild_${message.guild.id}`) || client.db.set(`level_${message.author.id}_guild_${message.guild.id}`, 1);;
    if (level > lvl) {
      let newLevel = client.db.set(`level_${message.author.id}_guild_${message.guild.id}`, level);
      let m = `${config.tada}**GG ${message.author.toString()}, You just advanced to level \`${newLevel}\`!**${config.tada}`
      message.channel.send(`${config.tada}**GG ${message.author.toString()}, You just advanced to level \`${newLevel}\`!**${config.tada}`);
    }
}

/*client.on('message', async message => {
  const PREFIX = client.db.get(`guild_${message.guild.id}_prefix`) || "x!"
  const args = message.content.substring(PREFIX.length).split(" ").slice(1)
  if (message.content === `${PREFIX}modlog`) {
    return message.channel.send('You don\'t have \`Manage_Server\` Permission to do this.')
  }

  let toggling = ["disbale", "enable"]
  //if (!toggling.includes(args[0])) {
  //    return channel.send('Please provide a valid options. Either **disable** or **enable** it.');
  //}

  if (args[0] === "enable") {
    let channel = message.mentions.channels.first();
    if (!channel) return message.channel.send('Please provide the channel that you want to make it as an audit log');

    await client.db.set(`Moderation_${message.guild.id}_modlog_toggle`, true);
    await client.db.set(`Moderation_${message.guild.id}_modlog_channel`, channel.id);
    return message.channel.send(`The audit log has been enabled for <#${channel.id}>`);
  }

  if (args[0] === 'disable') {
    let toggle = client.db.set(`Moderation_${message.guild.id}_modlog_toggle`);
    if (!toggle || toggle == false) return message.channel.send('I guess, the audit log has already been disabled before.');
    client.db.set(`Moderation_${message.guild.id}.modlog_toggle`, false);
    client.db.delete(`Moderation_${message.guild.id}_modlog_channel`)
    return message.channel.send("The audit log has been disabled");
  }
}
)*/

client.on('message', async (message) => {
  const PREFIX = client.db.get(`guild_${message.guild.id}_prefix`) || "x!"
  if (!message.content.startsWith(PREFIX)) return


  const args = message.content.substring(PREFIX.length).split(" ")

  if (message.content.startsWith(`${PREFIX}set-prefix`)) {
    if (!message.member.hasPermission("MANAGE_GUILD")) return message.channel.send("You don\'t have perms")
    if (!args[1]) return message.channel.send('You Need to specify a prefix.')
    if (!args[1].length > 3) return message.channel.send('A prefix can only be 3 or less charcters.')
    if (args[1] === client.db.get(`guild_${message.guild.id}_prefix`)) return message.channel.send('That is already your prefix.')
    if (args[1] === "x!") client.db.delete(`guild_${message.guild.id}_prefix`)
    client.db.set(`guild_${message.guild.id}_prefix`, args[1])
    return message.channel.send(`**I have now set your prefix to** \`${args[1]}\``)
  }
})


client.on('messageReactionAdd', async (reaction, user, message) => {
  const PREFIX = client.db.get(`guild_${reaction.message.guild.id}_prefix`) || "x!"
  var json = JSON.parse(fs.readFileSync("./ticket.json"))
  if (user.partial) await user.fetch();
  if (reaction.partial) await reaction.fetch();
  if (reaction.message.partial) await reaction.message.fetch();

  if (user.bot) return;
  var ticketid = client.db.get(`guild_${reaction.message.guild.id}_ticket`)

  if (reaction.message.id == ticketid && reaction.emoji.name === "📨") {
    reaction.users.remove(user);
    const ch = reaction.message.guild.channels.cache.find(channel => channel.name == `ticket-${user.username}`)
    if(ch){
      return reaction.message.channel.send("You already have a open ticket").then(m => m.delete({timeout: 5000}))
    }
    reaction.message.guild.channels.create(`ticket-${user.username}`, {
      permissionOverwrites: [
        {
          id: user.id,
          allow: ["VIEW_CHANNEL"]
        },
        {
          id: reaction.message.guild.roles.everyone,
          deny: ["VIEW_CHANNEL"]
        },
      ],
      type: 'text'
    }).then(async channel => {
      let embed = new Discord.MessageEmbed()
        .setTitle("Welcome to your ticket!")
        .setDescription(`Our suppurt team will be with you shortly\n======\n\`${PREFIX}close - To close the ticket | or react 🗑️\`\n\`${PREFIX}add @user\`\n\`${PREFIX}remove @user\`\n\`${PREFIX}rename <new name>\``)
        .setColor("BLUE")
        .setTimestamp()
        .setFooter(`${client.user.username}`, client.user.avatarURL())
      /*channel.send(`<@${user.id}>` ,{embed: embed})*/
      let msg = await channel.send(`<@${user.id}>`, { embed: embed })
      await msg.react("🗑️")
    })
  }
  ////////////////////
  var verifyid = client.db.get(`verify_${reaction.message.guild.id}`)
  var verifyrole = client.db.get(`roleV_${reaction.message.guild.id}`)
  if (reaction.message.id == verifyid) {
    /*reaction.users.remove(user);*/
    //user.roles.add(verifyrole.id)
    await reaction.message.guild.members.cache.get(user.id).roles.add(verifyrole)
    return user.send(`You successfully passed the verify in \`${reaction.message.guild.name}\``)

  }
  if (reaction.message.channel.name.startsWith("ticket-") && reaction.emoji.name === "🗑️") {
    reaction.message.channel.send(`\`${user.tag}\`, The ticket will delete in \`5 Seconds\``)
    setTimeout(() => {
      reaction.message.channel.delete();
    }, 5000);
  }
});

client.on('messageReactionRemove', async (reaction, user, message) => {
  if (user.partial) await user.fetch();
  if (reaction.partial) await reaction.fetch();
  if (reaction.message.partial) await reaction.message.fetch();

  if (user.bot) return;

  var verifyid = client.db.get(`verify_${reaction.message.guild.id}`)
  var verifyrole = client.db.get(`roleV_${reaction.message.guild.id}`)
  if (reaction.message.id == verifyid) {
    /*reaction.users.remove(user);*/

    await reaction.message.guild.members.cache.get(user.id).roles.remove(verifyrole)
    return;
  }
});


//Logs







client.login(config.token)