const { MessageEmbed } = require("discord.js");
const config = require('../config.json')
const db = require('quick.db')

module.exports = {
  name: "set-leave",
  description: "",
  async execute(client, message, args) {
  if(!message.member.hasPermission("MANAGE_MESSAGES")) return message.reply("You need `MANAGE_MESSAGES` permissions");
  const PREFIX = db.get(`guild_${message.guild.id}_prefix`) || "x!"
  let channel = message.mentions.channels.first();
  if(!channel) return message.channel.send('Please mention a channel' + `\nUsage: \`${PREFIX}set-leave #channel <message>\`\n\`{user} - for mention\`\n\`{guild} - for server name\`\n\`{user_tag} - for name#tag\``)
  let messageM = args.join(' ').replace(channel, "")
  if(!messageM) return message.channel.send('Please write a leave message')
  db.set(`leave_${message.guild.id}`, channel.id)
  db.set(`lMessage_${message.guild.id}`, messageM)

  let embed = new MessageEmbed()
  .setDescription(`${config.yes} | Leave channel has been set to: ${channel}\n${config.yes} | Leave message has been set to: ${messageM}`)
  .setColor("BLUE")

  message.channel.send(embed)
}
}
