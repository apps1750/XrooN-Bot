const Discord = require('discord.js')
const config = require('../config.json')
module.exports = {
    name: "add",
    description: "",
    async execute(client, message, args) {
        if (!message.channel.name.startsWith(`ticket-`)) return message.channel.send(`You are not in the ticket channel`)
        let newM = message.mentions.users.first()
        if(!newM) return message.reply('Please mention a user')
        message.channel.updateOverwrite(newM,{
            VIEW_CHANNEL: true 
        })
        const embed = new Discord.MessageEmbed()
        .setDescription(`**${config.yes} | ${newM}, Has been added to the ticket**`)
        .setColor("BLUE")
        message.channel.send(embed)
    }

}
