const Discord = require('discord.js');
const config = require("../config.json")
module.exports = {
  name: "embed",
  description: "",
  async execute(client, message, args) {
    if(!message.member.hasPermission('MANAGE_MESSAGES')) return message.channel.send('No Prems')
    let embed = new Discord.MessageEmbed()
    .setAuthor(message.author.tag , message.author.displayAvatarURL({dynamic : true}))
    .setDescription(args.join(' '))
    .setTimestamp()
    .setColor('BLUE')
    .setFooter(client.user.username , client.user.displayAvatarURL())
    message.channel.send(embed)
}

}
