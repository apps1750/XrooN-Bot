const { MessageEmbed } = require("discord.js");
const config = require('../config.json')
const db = require('quick.db')
const Topgg = require(`@top-gg/sdk`)
const api = new Topgg.Api(config.DBL_TOKEN)

module.exports = {
    name: "dbl",
    description: "",
    async execute(client, message, args) {
        const PREFIX = client.db.get(`guild_${message.guild.id}_prefix`) || "x!"
        let bot_id = args[0]
        if(!bot_id) return message.reply(`Usage: \`${PREFIX}dbl <bot_id>\``)
        try{
        let ido = await api.getBot(`${bot_id}`);
        let bot_embed = new MessageEmbed()
        .setAuthor('top.gg', "https://top.gg/images/dblnew.png", `https://top.gg/bot/${bot_id}`)
        .setThumbnail(`https://cdn.discordapp.com/avatars/${ido.id}/${ido.avatar}.png`)
        .setColor("BLUE")
        .addFields(
            {
                name: "Name: ",
                value: ido.username,
                inline: true
            },
            {
                name: "Discriminator: ",
                value: `#${ido.discriminator}`,
                inline: true
            },
            {
                name: "Prefix: ",
                value: `${ido.prefix}`,
                inline: true
            },
            {
                name: "Invite: ",
                value: `[Click Here](${ido.invite})`,
                inline: true
            },
            {
                name: "Tags: ",
                value: `${ido.tags}`,
                inline: true
            },
            {
                name: "Monthly Votes: ",
                value: `${ido.monthlyPoints} Votes`,
                inline: true
            },
            {
                name: "Servers Count: ",
                value: `${ido.server_count}`,
                inline: true
            },
            {
                name: "Support server ",
                value: `[Click Here](https://discord.gg/${ido.support})`,
                inline: true
            },
            {
                name: "Create Date ",
                value: `${ido.date}`,
                inline: true
            },
            {
                name: "Vote ",
                value: `[Click Here](https://top.gg/bot/${bot_id}/vote)`,
                inline: true
            },
        )
        .setDescription(`**Short desc:**\n${ido.shortdesc}`)
        //console.log(ido)
        message.channel.send(bot_embed)
        }catch(error){
                return message.reply('I don\'t find that bot in top.gg')
        }
    }

}


