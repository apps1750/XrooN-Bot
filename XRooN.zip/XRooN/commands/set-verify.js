const { MessageEmbed } = require("discord.js");
const config = require('../config.json')
const db = require('quick.db')

module.exports = {
  name: "set-verify",
  description: "",
  async execute(client, message, args) {
    if (!message.member.hasPermission("MANAGE_MESSAGES")) return message.reply("You need `MANAGE_MESSAGES` permissions");
    let ido = db.get(`verify_${message.guild.id}`)
    if(ido != null){
      return message.reply(`Verification system already enabled on this guild.`)
    }
    const PREFIX = db.get(`guild_${message.guild.id}_prefix`) || "x!"
    let channel = message.mentions.channels.first();
    if (!channel) return message.channel.send('Please mention a channel' + `\nUsage: \`${PREFIX}set-verify #channel <role-id>\``)
    let roleV = args[1]
    if (!roleV) return message.channel.send('Please write a verify role id')
    try {
      let sent = await channel.send(new MessageEmbed()
        .setTitle("Verify System")
        .setDescription("React with <a:verify:790103723593695282> to verify yourself")
        .setFooter(`${client.user.username} | Verify System`, client.user.displayAvatarURL())
        .setColor("BLUE")
      );

      sent.react('790103723593695282');

      db.set(`verify_${message.guild.id}`, sent.id)
      db.set(`roleV_${message.guild.id}`, roleV)

      let embed = new MessageEmbed()
        .setDescription(`${config.yes} | Verify channel has been set to: ${channel}\n${config.yes} | Verify role has been set to: <@&${roleV}>`)
        .setColor("BLUE")
      console.log(roleV)
      message.channel.send(embed)
    }catch (e){
      message.reply('It seems like i don\'t have the correct permission, plz give me \`ADMINISTRATOR\`, And dont forget to put my role above everyone.')
    }
  }
}