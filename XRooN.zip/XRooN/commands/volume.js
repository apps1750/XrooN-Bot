const Discord = require("discord.js");
const config = require('../config.json')
module.exports = {
  name: "volume",
  cooldown: 3,
  aliases: ["v"],
  description: "",
  async execute(client, message, args) {
    const queue = message.client.queue.get(message.guild.id);

    if (!queue) return message.reply("There is nothing playing.").catch(console.error);
    let embed = new Discord.MessageEmbed()
    .setDescription(`${config.yes} **| Volume successfully set to: \`${args[0]}%\`**`)
    .setColor('BLUE')

    let embed2 = new Discord.MessageEmbed()
    .setDescription(`**The currect volume is: \`${queue.volume}%\`**`)
    .setColor('BLUE')

    if (!args[0]) return message.reply(embed2).catch(console.error);
    if (isNaN(args[0])) return message.reply("Please use a number to set volume.").catch(console.error);
    if (Number(args[0]) > 100 || Number(args[0]) < 0 )
      return message.reply("Please use a number between 0 - 100.").catch(console.error);

    queue.volume = args[0];
    queue.connection.dispatcher.setVolumeLogarithmic(args[0] / 100);

    return queue.textChannel.send(embed).catch(console.error);
  
  }
}