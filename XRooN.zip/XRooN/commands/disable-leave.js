const { MessageEmbed } = require("discord.js");
const config = require('../config.json')
const db = require('quick.db')

module.exports = {
  name: "disable-leave",
  description: "",
  async execute(client, message, args) {
  if(!message.member.hasPermission("MANAGE_MESSAGES")) return message.reply("You need `MANAGE_MESSAGES` permissions");
  let ido = db.get(`leave_${message.guild.id}`)
  if(ido == null){
    return message.reply(`I can't disable something that does not exist`)
  }
  db.delete(`leave_${message.guild.id}`)
  db.delete(`lMessage_${message.guild.id}`)

  let embed = new MessageEmbed()
  .setDescription(`${config.yes} | Successfuly disable the leave!`)
  .setColor("BLUE")

  message.channel.send(embed)
}
}