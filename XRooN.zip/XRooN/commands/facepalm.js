const canvacord = require("canvacord");
const Discord = require("discord.js");

module.exports = {
    name: "facepalm",
    description: "",
    async execute(client, message, args) {
    let user = message.mentions.users.first() || client.users.cache.get(args[0]) || message.author;
    let facepalm = await canvacord.Canvas.facepalm(user.displayAvatarURL({ format: "png", dynamic: false }))
    let attachment = new Discord.MessageAttachment(facepalm, "XRooN-facepalm.png");
    let embed = new Discord.MessageEmbed()
    .setImage(`attachment://XRooN-facepalm.png`)
    .attachFiles(attachment)
    .setColor('BLUE')
    .setTimestamp()    
    .setFooter(client.user.username , client.user.displayAvatarURL({ format: "png", dynamic: false }))
    return message.channel.send(embed);
}
}
