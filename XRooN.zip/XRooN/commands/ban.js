const { MessageEmbed } = require('discord.js');
const config = require("../config.json")
const db = require('quick.db')
module.exports = {
    name: "ban",
    description: "",
    async execute(client, message, args) {
        if (!message.member.hasPermission('BAN_MEMBERS')) {
            return message.channel.send(`You are unable to ban members`)
        }
        const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        if(!member) return message.reply('Plz mention a user!')


        try {
            await member.ban();
            let embed = new MessageEmbed()
            .setDescription(`${config.yes} **| ${member} has been banned!**`)
            .setColor("BLUE")
            await message.channel.send(embed)

        } catch (e) {
            console.log(e)
            return message.channel.send(`User is not in the server!`)
        }

    }
}