module.exports = {
  name: "close",
  description: "",
  async execute(client, message, args) {
    if (!message.channel.name.startsWith(`ticket-`)) return message.channel.send(`You are not in the ticket channel`)
    message.channel.send(`<@${message.author.id}>, The ticket will be closed in ` + "`5 Seconds`.")
    setTimeout(() => {
      message.channel.delete();
    }, 5000);
  }

}