const Discord = require('discord.js');
const config = require("../config.json")
const canvacord = require("canvacord");
module.exports = {
  name: "circle",
  description: "",
  async execute(client, message, args) {
    let user = message.mentions.users.first() || client.users.cache.get(args[0]) || message.author;
    let circle = await canvacord.Canvas.circle(user.displayAvatarURL({ format: "png", dynamic: false }))
    let at = new Discord.MessageAttachment(circle, "XRooN-circle.png")


  let embed = new Discord.MessageEmbed()
  .setImage(`attachment://XRooN-circle.png`)
  .attachFiles(at)
  .setColor('BLUE')
  .setTimestamp()    
  .setFooter(client.user.username , client.user.displayAvatarURL({ format: "png", dynamic: false }))
  return message.channel.send(embed);
}

}