const { MessageEmbed } = require("discord.js");

module.exports = {
  name: "pause",
  description: "",
  async execute(client, message, args) {
    const queue = message.client.queue.get(message.guild.id);
    if (!queue) return message.reply("There is nothing playing.").catch(console.error);

    if (queue.playing) {
      queue.playing = false;
      queue.connection.dispatcher.pause(true);
      let embed = new MessageEmbed()
      .setDescription(`${message.author} ⏸ paused the music.`)
      .setColor('BLUE')
      return queue.textChannel.send(embed).catch(console.error);
    }
  
}
}