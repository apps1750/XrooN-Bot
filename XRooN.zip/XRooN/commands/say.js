const Discord = require('discord.js');
const config = require("../config.json")
module.exports = {
  name: "say",
  description: "",
  async execute(client, message, args) {
    if(!message.member.hasPermission('MANAGE_MESSAGES')) return message.channel.send('No Prems')
    message.channel.send(args.join(' '))
}

}