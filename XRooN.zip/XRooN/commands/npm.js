const Discord = require("discord.js");

module.exports = {
    name: "npm",
    description: "",
    async execute(client, message, args) {
  

}

}
