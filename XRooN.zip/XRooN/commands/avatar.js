const Discord = require('discord.js');
const config = require("../config.json")
module.exports = {
    name: "avatar",
    description: "",
    async execute(client, message, args) {
    const embed = new Discord.MessageEmbed();
    if(!message.mentions.users.first()){
        let pngAvatar = message.author.displayAvatarURL({format: "png"})
        let jpgAvatar = message.author.displayAvatarURL({format: "jpg"})
        let webpAvatar = message.author.displayAvatarURL({format: "webp"})
        let gifAvatar = message.author.displayAvatarURL({dynamic:true})
        embed.setTitle("Your Avatar:")
        embed.setImage(message.author.displayAvatarURL({dynamic:true}))
        embed.setDescription(`**Save As:**\n[Png](${pngAvatar}) | [Jpg](${jpgAvatar}) | [Webp](${webpAvatar}) | [Source](${gifAvatar})`)
        embed.setColor("BLUE")
        embed.setFooter(message.author.tag ,message.author.displayAvatarURL({dynamic:true}))
        return message.channel.send(embed)
    }else{
        const user = message.mentions.users.first()
        let pngAvatar = user.displayAvatarURL({format: "png"})
        let jpgAvatar = user.displayAvatarURL({format: "jpg"})
        let webpAvatar = user.displayAvatarURL({format: "webp"})
        let gifAvatar = user.displayAvatarURL({dynamic:true})
        embed.setTitle(`${user.tag}'s Avatar:`)
        embed.setImage(user.displayAvatarURL({dynamic:true}))
        embed.setDescription(`**Save As:**\n[Png](${pngAvatar}) | [Jpg](${jpgAvatar}) | [Webp](${webpAvatar}) | [Source](${gifAvatar})`)
        embed.setColor("BLUE")
        embed.setFooter(user.tag,user.displayAvatarURL({dynamic:true}))
        return message.channel.send(embed)
    }
}

}