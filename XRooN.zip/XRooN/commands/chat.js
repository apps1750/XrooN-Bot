const Discord = require('discord.js');
const config = require("../config.json")
const fetch = require("node-fetch")
module.exports = {
  name: "chat",
  description: "",
  async execute(client, message, args) {
    let msg = args.join(' ');
    if(!msg) return message.reply('Write something!').then(m => m.delete({timeout: 5000}))
    fetch(`http://api.brainshop.ai/get?bid=154296&key=34LR26SpCeJ6fWBt&uid=1&msg=${encodeURIComponent(msg)}`)
    .then(res => res.json())
    .then(data =>{
        message.channel.send(data.cnt)
    });

}
}