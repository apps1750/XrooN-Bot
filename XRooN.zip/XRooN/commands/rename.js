const Discord = require('discord.js')
const config = require('../config.json')
module.exports = {
        name: "rename",
        description: "",
        async execute(client, message, args) {
                if (!message.channel.name.startsWith(`ticket-`)) return message.channel.send(`You are not in the ticket channel`)
                let newName = args.join(" ");
                if (newName.length < 1) return message.channel.send("Please write a new name")
                message.channel.setName(`ticket-${newName}`)
                const embed = new Discord.MessageEmbed()
                        .setDescription(`**${config.yes} | Channel name has been changed to: \`ticket-${newName}\`**`)
                        .setColor("BLUE")
                message.channel.send(embed)

        }

}