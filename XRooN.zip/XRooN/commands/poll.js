const Discord = require('discord.js');
const config = require("../config.json")
module.exports = {
  name: "poll",
  description: "",
  async execute(client, message, args) {
    message.delete()
    if(args.join(' ') <= 0) return message.reply('I can\'t poll nothing').then(m => m.delete({timeout: 5000}))
    let embed = new Discord.MessageEmbed()
    .setAuthor(message.author.tag , message.author.displayAvatarURL({dynamic : true}))
    .setDescription(args.join(' ') + `\n\nYes: ${config.yes} | No: ${config.no}`)
    .setColor("BLUE")
    
    let msg = await message.channel.send(embed)
    await msg.react("788370076952821760")
    await msg.react("788370077040902154")
    
}

}