const { MessageEmbed } = require("discord.js");
const ms = require('ms');
const config = require("../config.json")
const db = require("quick.db")
module.exports = {
    name: "start",
    description: "",
    async execute(client, message, args) {
    const P = client.db.get(`guild_${message.guild.id}_prefix`) || "x!"
    //emdes:
    const noP = new MessageEmbed()
    .setDescription(`${config.no} | You need to have the manage messages permissions to start giveaways.`)
    .setColor("BLUE")

    const noC = new MessageEmbed()
    .setDescription(`${config.no} | You have to mention a valid channel!\nUsage: \`${P}start #channel <time (s,m,h,d)> <winner(s)> [Prize]\``)
    .setColor("BLUE")

    const noT = new MessageEmbed()
    .setDescription(`${config.no} | You have to specify a valid duration!`)
    .setColor("BLUE")

    const noW = new MessageEmbed()
    .setDescription(`${config.no} | You have to specify a valid number of winners!`) 
    .setColor("BLUE")
    
    const noPr = new MessageEmbed()
    .setDescription(`${config.no} | You have to specify a valid prize!`) 
    .setColor("BLUE")

    // If the member doesn't have enough permissions
    if(!message.member.hasPermission('MANAGE_MESSAGES') && !message.member.roles.cache.some((r) => r.name === "Giveaways")){
        return message.channel.send(noP);
    }

    // Giveaway channel
    let giveawayChannel = message.mentions.channels.first();
    // If no channel is mentionned
    if(!giveawayChannel){
        return message.channel.send(noC);
    }

    // Giveaway duration
    let giveawayDuration = args[1];
    // If the duration isn't valid
    if(!giveawayDuration || isNaN(ms(giveawayDuration))){
        return message.channel.send(noT);
    }

    // Number of winners
    let giveawayNumberWinners = args[2];
    // If the specified number of winners is not a number
    if(isNaN(giveawayNumberWinners) || (parseInt(giveawayNumberWinners) <= 0)){
        return message.channel.send(noW);
    }

    // Giveaway prize
    let giveawayPrize = args.slice(3).join(' ');
    // If no prize is specified
    if(!giveawayPrize){
        return message.channel.send(noPr);
    }

    // Start the giveaway
    client.giveawaysManager.start(giveawayChannel, {
        // The giveaway duration
        time: ms(giveawayDuration),
        // The giveaway prize
        prize: giveawayPrize,
        // The giveaway winner count
        winnerCount: giveawayNumberWinners,
        // Who hosts this giveaway
        hostedBy: message.author,
        // Messages
        messages: {
            giveaway: `${config.tada}${config.tada}**GIVEAWAY** ${config.tada}${config.tada}`,
            giveawayEnded: `${config.tada}${config.tada}**GIVEAWAY ENDED** ${config.tada}${config.tada}`,
            timeRemaining: `Time remaining: \`{duration}\`!`,
            inviteToParticipate: `React with ${config.tada} to participate!`,
            winMessage: config.tada + "Congratulations, {winners}! You won `{prize}`!",
            embedFooter: "Giveaways",
            noWinner: "Giveaway cancelled, no valid participations.",
            hostedBy: "Hosted by: {user}",
            winners: "winner(s)",
            endedAt: "Ended at",
            units: {
                seconds: "seconds",
                minutes: "minutes",
                hours: "hours",
                days: "days",
                pluralS: false // Not needed, because units end with a S so it will automatically removed if the unit value is lower than 2
            }
        }
    });

    message.channel.send(`Giveaway started in ${giveawayChannel}!`);
 }
}