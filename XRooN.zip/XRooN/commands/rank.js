const { MessageAttachment } = require("discord.js");
const canvacord = require("canvacord");
const config = require('../config.json')
const db = require('quick.db')

module.exports = {
  name: "rank",
  description: "",
  async execute(client, message, args) {
    let user = message.mentions.users.first() || client.users.cache.get(args[0]) || message.author;

    let level = client.db.get(`level_${user.id}_guild_${message.guild.id}`) || 0;
    let exp = client.db.get(`xp_${user.id}_guild_${message.guild.id}`) || 0;
    let neededXP = Math.floor(Math.pow(level / 0.1, 2));

    let every = client.db.all().filter(i => i.ID.startsWith("xp_")).sort((a, b) => b.data - a.data);
    //let rank = every.map(x => x.ID).indexOf(`xp_${user.id}_guild_${message.guild.id}`) + 1;
    let rank = level + 1

    const card = new canvacord.Rank()
      .setUsername(user.username)
      .setDiscriminator(user.discriminator)
      .setRank(rank)
      .setLevel(level)
      .setCurrentXP(exp)
      .setRequiredXP(neededXP)
      .setOverlay("BLACK", 0.7 , true)
      .setBackground("IMAGE","https://cdn.discordapp.com/attachments/694924467415285801/790905945180864522/Untitled-1.png")
      .setStatus(user.presence.status)
      //.setBackground("COLOR" , "BLUE")
      .setAvatar(user.displayAvatarURL({ format: "png", size: 512 }));

    const img = await card.build();

    return message.channel.send(new MessageAttachment(img, "XRooN-RankCard.png"));
  }

}
