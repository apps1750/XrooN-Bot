const Discord = require('discord.js');
const config = require("../config.json")
const ms = require('ms')
module.exports = {
    name: "mute",
    description: "",
    async execute(client, message, args) {
    if(!message.member.hasPermission('MANAGE_MESSAGES')) return message.reply('You can\'t use that!');

    var user = message.mentions.users.first();
    if (!user) return message.reply('You didn\'t mention anyone!');

    var member;

    try {
        member = await message.guild.members.fetch(user);
    } catch (err) {
        member = null;
    }

    if (!member) return message.reply('They aren\'t in the server!');
    if (member.hasPermission('MANAGE_MESSAGES')) return message.reply('You cannot mute that person!');

    var rawTime = args[1];
    var time = ms(rawTime);
    if (!time) return message.reply('You didn\'t specify a time!');

    var embed = new Discord.MessageEmbed()
        .setTitle('You were muted!')
        .addField('Expires:', rawTime, true)
    //.addField('Reason:', reason, true);

    try {
        user.send(embed);
    } catch (err) {
        console.warn(err);
    }

    var role = message.guild.roles.cache.find(r => r.name === 'muted');
    if (!role) {
        try {
            role = await message.guild.roles.create({
                data: { name: "muted", color: "#000000", permissions: [] }
            });
            message.guild.channels.cache.forEach(channel => {
                if (channel.type == 'voice') {
                    channel.updateOverwrite(role, { SPEAK: false })
                } else if (channel.type == 'text') {
                    channel.updateOverwrite(role, { SEND_MESSAGES: false })
                }
            })
            const embed13 = new Discord.MessageEmbed()
                .setDescription(`<@${message.author.id}> **(${message.author.tag}), I can't find the mute role. so i create one!**`)
                .setColor(config.mainColor)
            message.channel.send(embed13);
        } catch (e) {
            console.log(e.stack);
        }
    }

    member.roles.add(role);

    setTimeout(function () {
        member.roles.remove(role);
        const embed12 = new Discord.MessageEmbed()
            .setDescription(`${config.no}**${user} has been unmuted!**`)
            .setColor(config.mainColor)
        message.channel.send(embed12);
    }, time);

    const embed1 = new Discord.MessageEmbed()
        .setDescription(`${config.yes}**${user} has been muted by ${message.author} for ${rawTime}**!`)
        .setColor(config.mainColor)
    message.channel.send(embed1);


}

}