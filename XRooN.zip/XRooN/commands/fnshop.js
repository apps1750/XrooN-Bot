const Discord = require('discord.js');
const config = require("../config.json");
const Canvas = require("discord-canvas")
module.exports = {
  name: "fnshop",
  description: "",
  async execute(client, message, args) {
    const image = await new Canvas.FortniteShop()
    .setToken("706c247f-027a-4f31-847e-616b2945a10c")
    .toAttachment();
    
  let attachment = new Discord.MessageAttachment(image, "XRooN-FortniteShop.png");    
  let embed = new Discord.MessageEmbed()
  .setImage(`attachment://XRooN-FortniteShop.png`)
  .attachFiles(attachment)
  .setColor('BLUE')
  .setTimestamp()    
  .setFooter(client.user.username , client.user.displayAvatarURL({ format: "png", dynamic: false }))
  return message.channel.send(embed);
}

}