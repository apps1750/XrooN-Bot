const Discord = require('discord.js');
const config = require("../config.json")
const os = require('os')
const Topgg = require(`@top-gg/sdk`)
const api = new Topgg.Api(config.DBL_TOKEN)

module.exports = {
    name: "bot-info",
    aliases: ["bi"],
    description: "",
    async execute(client, message, args) {
    let ido = await api.getBot('786975444561297510');
  const embed = new Discord.MessageEmbed()
  .setThumbnail(client.user.displayAvatarURL({dynamic: true}))
  .setTitle('Bot Stats')
  .setColor("BLUE")
  .addFields(
      {
          name: '\\🌐 Servers',
          value: `\`${client.guilds.cache.size}\` Servers.`,
          inline: true
      },
      {
          name: '\\📺 Channels',
          value: `\`${client.channels.cache.size}\` Channels.`,
          inline: true
      },
      {
          name: '\\👥 Server Users',
          value: `\`${client.users.cache.size}\` Users`,
          inline: true
      },
      {
          name: '\\⏳ Ping',
          value: `\`${Math.round(client.ws.ping)}\` ms`,
          inline: true
      },
      {
          name: '\\✌️ Join Date',
          value: client.user.createdAt,
          inline: true
      },
      {
          name: '\\📊 Server Info',
          value: `Cores: \`${os.cpus().length}\``,
          inline: true
      },
      {
        name: '<:top_gg:793225978599833602> Votes',
        value: `\`${ido.monthlyPoints}\` Votes`,
        inline: true
    }
  )
  .setFooter(`Asked By: ${message.author.tag}`, message.author.displayAvatarURL({dynamic: true}))

await message.channel.send(embed)
}


}