const Discord = require('discord.js');
const config = require("../config.json")
module.exports = {
    name: "user-info",
    aliases: ["ui"],
    description: "",
    async execute(client, message, args) {
    let user = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;

    let status;
    switch (user.presence.status) {
        case "online":
            status = "<:ONLINE:792152550987530252> | Online";
            break;
        case "dnd":
            status = "<:DND:792152550962757662> | Do Not Disturb";
            break;
        case "idle":
            status = "<:IDLE:792152550907314186> | Idle";
            break;
        case "offline":
            status = "<:OFFLINE:792152551109033984> | Offline/Invisble";
            break;
    }

    const embed = new Discord.MessageEmbed()
        .setTitle(`${user.user.tag} stats`, user.user.displayAvatarURL({dynamic : true}))
        .setColor("BLUE")
        .setThumbnail(user.user.displayAvatarURL({dynamic : true}))
        .addFields(
            {
                name: "Name: ",
                value: user.user.username,
                inline: true
            },
            {
                name: "Discriminator: ",
                value: `#${user.user.discriminator}`,
                inline: true
            },
            {
                name: "ID: ",
                value: user.user.id,
            },
            {
                name: "Current Status: ",
                value: status,
                inline: true
            },
            {
                name: "Badges: ",
                value: getFlagsAsString(user.user.flags.toArray()),
                inline: true
            },
            {
                name: "Activity: ",
                value: user.presence.activities[0] ? user.presence.activities[0].name : `User isn't playing a game!`,
                inline: true
            },
            {
                name: 'Avatar link: ',
                value: `[Click Here](${user.user.displayAvatarURL({dynamic: true})})`
            },
            {
                name: 'Creation Date: ',
                value: user.user.createdAt.toLocaleDateString("en-us"),
                inline: true
            },
            {
                name: 'Joined Date: ',
                value: user.joinedAt.toLocaleDateString("en-us"),
                inline: true
            },
            {
                name: 'User Roles: ',
                value: user.roles.cache.map(role => role.toString()).join(" ,"),
                inline: true
            }
        )

    await message.channel.send(embed)

}
}

function getFlagsAsString(flags) {
    var result = "";
    for(var i = 0; i < flags.length; i++) {
        if(i + 1 == flags.length && flags[i] !== "EARLY_VERIFIED_DEVELOPER") { 
            result += flags[i]
        } else if(flags[i] !== "EARLY_VERIFIED_DEVELOPER") {
            result += flags[i] + ", ";
        }
    }
    if(result === "") result = "`NONE`"
    return result.replace('PARTNERED_SERVER_OWNER','<:Discord_Partner:792149618959974441>').replace('HYPESQUAD_EVENTS','<:HYPESQUAD_EVENTS:792149619341393940>').replace('BUGHUNTER_LEVEL_1','<:BugHunter:792149619072434176>').replace('HOUSE_BRAVERY','<:HOUSE_BRAVERY:792149619257376819>').replace('HOUSE_BRILLIANCE','<:HOUSE_BRILLIANCE:792149619479412767>').replace('HOUSE_BALANCE','<:HOUSE_BALANCE:792149619102580756>').replace('EARLY_SUPPORTER','<:EARLY_SUPPORTER:792151463609892874>').replace('BUGHUNTER_LEVEL_2','<:BugHunterV2:792149619131809832>').replace('VERIFIED_BOT','<:verified_bot:792149619395657738>').replace('VERIFIED_DEVELOPER','<:verifieddev:792149619630407720>');
}