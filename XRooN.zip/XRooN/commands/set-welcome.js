const { MessageEmbed } = require("discord.js");
const config = require('../config.json')
const db = require('quick.db')

module.exports = {
  name: "set-welcome",
  description: "",
  async execute(client, message, args) {
  if(!message.member.hasPermission("MANAGE_MESSAGES")) return message.reply("You need `MANAGE_MESSAGES` permissions");
  const PREFIX = db.get(`guild_${message.guild.id}_prefix`) || "x!"
  let ido = db.get(`welcome_${message.guild.id}`)
  if(ido != null){
    return message.reply(`Welcome message already enable on this guild Use \`${PREFIX}disable-welcome\` to disable`)
  }
  let channel = message.mentions.channels.first();
  if(!channel) return message.channel.send('Please mention a channel' + `\nUsage: \`${PREFIX}set-welcome #channel <message>\`\n\`{user} - for mention\`\n\`{guild} - for server name\`\n\`{user_tag} - for name#tag\``)
  let messageM = args.join(' ').replace(channel, "")
  if(!messageM) return message.channel.send('Please write a welcome message')
  db.set(`welcome_${message.guild.id}`, channel.id)
  db.set(`wMessage_${message.guild.id}`, messageM)

  let embed = new MessageEmbed()
  .setDescription(`${config.yes} | Welcome channel has been set to: ${channel}\n${config.yes} | Welcome message has been set to: ${messageM}`)
  .setColor("BLUE")

  message.channel.send(embed)
}
}
