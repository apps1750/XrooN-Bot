const { MessageEmbed } = require("discord.js");

module.exports = {
  name: "resume",
  description: "",
  async execute(client, message, args) {
    const queue = message.client.queue.get(message.guild.id);
    if (!queue) return message.reply("There is nothing playing.").catch(console.error);

    if (!queue.playing) {
      queue.playing = true;
      queue.connection.dispatcher.resume();
      let embed = new MessageEmbed()
        .setDescription(`${message.author} ▶ resumed the music!`)
        .setColor('BLUE')
      return queue.textChannel.send(embed).catch(console.error);
    }

    return message.reply("The queue is not paused.").catch(console.error);

  }
}