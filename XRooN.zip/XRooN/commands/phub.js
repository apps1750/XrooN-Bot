const Discord = require('discord.js');
const config = require("../config.json")
const canvacord = require("canvacord");
module.exports = {
  name: "phub",
  description: "",
  async execute(client, message, args) {
  const PREFIX = client.db.get(`guild_${message.guild.id}_prefix`) || "x!"
    if(args.length <= 0) return message.channel.send(`Usage: \`${PREFIX}phub @mention <somthing>\``)
    let user = message.mentions.users.first() || client.users.cache.get(args[0]);
    if(!user) return message.channel.send('You need to mention a user')
    let botM = args.slice(1).join(' ')
    if(!botM) return message.channel.send('Write something')
    let phub = await canvacord.Canvas.phub({username: user.username , message: botM , image: user.displayAvatarURL({ format: "png", dynamic: false })})
    let at = new Discord.MessageAttachment(phub, "XRooN-phub.png")

    let embed = new Discord.MessageEmbed()
    .setImage(`attachment://XRooN-phub.png`)
    .attachFiles(at)
    .setColor('BLUE')
    .setTimestamp()    
    .setFooter(client.user.username , client.user.displayAvatarURL({ format: "png", dynamic: false }))
    return message.channel.send(embed);
}
}