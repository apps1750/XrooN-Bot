const canvacord = require("canvacord");
const Discord = require("discord.js");

module.exports = {
    name: "gay",
    description: "",
    async execute(client, message, args) {
    let user = message.mentions.users.first() || client.users.cache.get(args[0]) || message.author;
    let gay = await canvacord.Canvas.rainbow(user.displayAvatarURL({ format: "png", dynamic: false }));
    let attachment = new Discord.MessageAttachment(gay, "XRooN-gay.png");
    let embed = new Discord.MessageEmbed()
    .setImage(`attachment://XRooN-gay.png`)
    .attachFiles(attachment)
    .setColor('BLUE')
    .setTimestamp()    
    .setFooter(client.user.username , client.user.displayAvatarURL({ format: "png", dynamic: false }))
    return message.channel.send(embed);
}

}
