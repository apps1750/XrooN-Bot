const canvacord = require("canvacord");
const Discord = require("discord.js");

module.exports = {
    name: "slap",
    description: "",
    async execute(client, message, args) {
    let user = message.mentions.users.first() || client.users.cache.get(args[0]);
    if(!user) return message.channel.send('Please mention a user to slap')
    let slap = await canvacord.Canvas.slap(message.author.displayAvatarURL({ format: "png", dynamic: false }) , user.displayAvatarURL({ format: "png", dynamic: false }))
    let attachment = new Discord.MessageAttachment(slap, "XRooN-slap.png");
    let embed = new Discord.MessageEmbed()
    .setImage(`attachment://XRooN-slap.png`)
    .setDescription('**I like your cut G**')
    .attachFiles(attachment)
    .setColor('BLUE')
    .setTimestamp()    
    .setFooter(client.user.username , client.user.displayAvatarURL({ format: "png", dynamic: false }))
    return message.channel.send(embed);
}

}
