const canvacord = require("canvacord");
const Discord = require("discord.js");

module.exports = {
    name: "hitler",
    description: "",
    async execute(client, message, args) {
    let user = message.mentions.users.first() || client.users.cache.get(args[0]) || message.author;
    let hitler = await canvacord.Canvas.hitler(user.displayAvatarURL({ format: "png", dynamic: false }));
    let attachment = new Discord.MessageAttachment(hitler, "XRooN-hitler.png");
    let embed = new Discord.MessageEmbed()
    .setImage(`attachment://XRooN-hitler.png`)
    .attachFiles(attachment)
    .setColor('BLUE')
    .setTimestamp()    
    .setFooter(client.user.username , client.user.displayAvatarURL({ format: "png", dynamic: false }))
    return message.channel.send(embed);
}
}
