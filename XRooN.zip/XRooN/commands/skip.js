const { MessageEmbed } = require("discord.js");

module.exports = {
  name: "skip",
  aliases: ["s"],
  description: "",
  async execute(client, message, args) {
  const queue = message.client.queue.get(message.guild.id);
  if (!queue)
    return message.reply("There is nothing playing that I could skip for you.").catch(console.error);

  queue.playing = true;
  queue.connection.dispatcher.end();
  let embed = new MessageEmbed()
  .setDescription(`${message.author} ⏭ skipped the song`)
  .setColor("BLUE")
  queue.textChannel.send(embed).catch(console.error);
  
}

}