const Discord = require('discord.js');
const config = require("../config.json")
const canvacord = require("canvacord");
module.exports = {
  name: "wanted",
  description: "",
  async execute(client, message, args) {
    let user = message.mentions.users.first() || client.users.cache.get(args[0]) || message.author;
    let wanted = await canvacord.Canvas.wanted(user.displayAvatarURL({ format: "png", dynamic: false }))
    let at = new Discord.MessageAttachment(wanted, "XRooN-wanted.png")
    let embed = new Discord.MessageEmbed()
    .setImage(`attachment://XRooN-wanted.png`)
    .attachFiles(at)
    .setColor('BLUE')
    .setTimestamp()    
    .setFooter(client.user.username , client.user.displayAvatarURL({ format: "png", dynamic: false }))
    return message.channel.send(embed);
}
}