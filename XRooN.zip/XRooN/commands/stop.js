const { MessageEmbed } = require("discord.js");

module.exports = {
  name: "stop",
  description: "",
  async execute(client, message, args) {
    const queue = message.client.queue.get(message.guild.id);
    if (!queue)
      return message.reply("There is nothing playing that I could skip for you.").catch(console.error);

    queue.songs = [];
    queue.connection.dispatcher.end();;
    let embed = new MessageEmbed()
      .setDescription(`${message.author} ⏹ stopped the music!`)
      .setColor("BLUE")
    queue.textChannel.send(embed).catch(console.error);

  }
}